const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");

menuToggle?.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", open);
});

document.querySelectorAll(".nav a").forEach(link => {
  link.addEventListener("click", () => nav.classList.remove("open"));
});

// Product filters
const filterButtons = document.querySelectorAll(".filter-tabs button");
const products = document.querySelectorAll("#productGrid .product-card");

filterButtons.forEach(button => {
  button.addEventListener("click", () => {
    filterButtons.forEach(btn => btn.classList.remove("active"));
    button.classList.add("active");

    const filter = button.dataset.filter;

    products.forEach(product => {
      product.classList.toggle(
        "hidden",
        filter !== "all" && product.dataset.category !== filter
      );
    });
  });
});

// Tiny cart interaction
const toast = document.getElementById("toast");

document.querySelectorAll(".add-btn").forEach(button => {
  button.addEventListener("click", () => {
    toast.textContent = `${button.dataset.name} added to cart ✓`;
    toast.classList.add("show");

    setTimeout(() => {
      toast.classList.remove("show");
    }, 2200);
  });
});

// Newsletter
const newsletterForm = document.getElementById("newsletterForm");
const formMessage = document.getElementById("formMessage");

newsletterForm?.addEventListener("submit", event => {
  event.preventDefault();

  const email = newsletterForm.querySelector("input").value;
  formMessage.textContent = `Thanks! ${email} is now subscribed.`;
  newsletterForm.reset();
});
