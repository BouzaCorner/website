# Frozen Flakes Ice Cream Shop

A responsive ice-cream shop landing page inspired by the supplied design reference.

## Files

- `index.html` — page structure/content
- `style.css` — responsive styling
- `script.js` — mobile menu, product filters, cart toast and newsletter interaction

## Run locally

Open `index.html` directly in your browser, or use VS Code Live Server.

## Publish on GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your `main` branch and `/root`.
6. Save.

The page will then be available through your GitHub Pages URL.

## Customize

Change the brand name, text, prices and image URLs directly in `index.html`.
Change the main pink tones in the `:root` section of `style.css`.
